=== Js Start Two ===
Contributors: jstreemscloud
Requires at least: 6.1
Tested up to: 6.2.2
Stable tag: 1.0.
Requires PHP: 7.4
License: GPL-2.0-or-later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Js Start Two is a theme design by Jstreems Cloud, optimized for fast web load and bringing you the full power of WordPress Block Theme, html and least php.

As the team behind WordPress Block Theme will say:
Whether you want to build a complex or incredibly simple website, you can do it quickly and intuitively through the bundled styles or dive into creation and full customization yourself.


== Changelog ==

= 1.0.0 =
* Created: June 8, 2023


== Copyright ==

© Copyright Js Start Two 2023, Jstreems Cloud.